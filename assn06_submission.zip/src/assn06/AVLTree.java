package assn06;

public class AVLTree<T extends Comparable<T>> implements SelfBalancingBST<T> {
    // Fields
    private T _value;
    private AVLTree<T> _left;
    private AVLTree<T> _right;
    private int _height;
    private int _size;
    
    public AVLTree() {
        _value = null;
        _left = null;
        _right = null;
        _height = -1;
        _size = 0;
    }

    /**
     * Rotates the tree left and returns
     * AVLTree root for rotated result.
     */
     private AVLTree<T> rotateLeft() {
         // You should implement left rotation and then use this 
         // method as needed when fixing imbalances.
    	 // TODO
         AVLTree<T> newRoot = _right;
         _right = newRoot._left;
         newRoot._left = this;
         updateHeightAndSize();
         newRoot.updateHeightAndSize();

         return newRoot;
     }
    
    /**
     * Rotates the tree right and returns
     * AVLTree root for rotated result.
     */
     private AVLTree<T> rotateRight() {
         // You should implement right rotation and then use this 
         // method as needed when fixing imbalances.
    	 // TODO
         AVLTree<T> newRoot = _left;
         _left = newRoot._right;
         newRoot._right = this;
         updateHeightAndSize();
         newRoot.updateHeightAndSize();

         return newRoot;
     }

    @Override
    public boolean isEmpty() {
         return size() == 0;
    }

    @Override
    public int height() {

         return _height;
    }

    @Override
    public int size() {

         return _size;
    }

    @Override
    public SelfBalancingBST<T> insert(T element) {
    	// TODO
       if(isEmpty()) {
           _value = element;
           _height = 0;
           _size = 1;
           _left = new AVLTree<>();
           _right = new AVLTree<>();
       }
        else {
            if(element.compareTo(_value) < 0) {
                _left = (AVLTree<T>) _left.insert(element);
           }
           else {
              _right = (AVLTree<T>) _right.insert(element);

           }
           updateHeightAndSize();
           balanceTree();
        }
        return this;
    }

    private void updateHeightAndSize(){
         _height = 1 + Math.max(_left.height(), _right.height());
         _size = _left.size() + _right.size() + 1;
     }

    private AVLTree<T> balanceTree(){

        if (getBalance() > 1) {
            if (_left.getBalance() < 0) {
                _left = _left.rotateLeft();
            }
            return rotateRight();
        } else if (getBalance() < -1) {
            if (_right.getBalance() > 0) {
                _right = _right.rotateRight();
            }
            return rotateLeft();
        }
        return this;
    }

    private int getBalance(){
         return _left.height() - _right.height();
    }

    @Override
    public SelfBalancingBST<T> remove(T element) {
        // TODO

        if (isEmpty()) {
            return null;
        }
        if(element.compareTo(_value) < 0 ){
            _left = (AVLTree<T>) _left.remove(element);
        }
        else if (element.compareTo(_value) > 0 ) {
            _right = (AVLTree<T>) _right.remove(element);
        }
        else {
            if(_left == null) {
                return _right;
            }
            else if(_right == null){
                return _left;
            }
            else{
                _value = _right.findMin();
                _right = (AVLTree<T>) _right.remove(_value);
            }
        }
        updateHeightAndSize();
        balanceTree();
        return this;
    }

    @Override
    public T findMin() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
        // TODO

        if(getLeft().isEmpty()){
            return getValue();
        }
        return getLeft().findMin();
    }

    @Override
    public T findMax() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
        // TODO

        if (getRight().isEmpty()){
            return  getValue();
        }
        return getRight().findMax();
    }

    @Override
    public boolean contains(T element) {
    	// TODO
        if (isEmpty()) {
            return false;
        }

        if(element.compareTo(_value) < 0){
            return _left.contains(element);
        }
        else if(element.compareTo(_value) > 0){
            return _right.contains(element);
        }
        else {
            return true;
        }
    }


    @Override
    public boolean rangeContain(T start, T end) {
        // TODO

        if(isEmpty()) {
            return false;
        }
        if(start.compareTo(_value) < 0){
            return _left.rangeContain(start, end);
        }
        else if (end.compareTo(_value) < 0){
            return _right.rangeContain(start, end);
        }
        else {
            return contains(start) && contains(end);
        }
    }

    @Override
    public T getValue() {
        return _value;
    }

    @Override
    public SelfBalancingBST<T> getLeft() {
        if (isEmpty()) {
            return null;
        }
        return _left;
    }

    @Override
    public SelfBalancingBST<T> getRight() {
        if (isEmpty()) {
            return null;
        }
         return _right;
    }

}

